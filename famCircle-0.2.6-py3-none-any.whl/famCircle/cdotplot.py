import re
import sys

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from famCircle.bez import *


class cdotplot():
    def __init__(self, options):

        self.score = 100
        self.evalue = 1e-5
        self.markersize = 0.5
        self.block = 4
        self.block_gep = 0
        self.figsize = 'default'
        self.position = 'order'
        self.blast_reverse = 'False'
        self.genome_name_size = '20'
        self.chr_name_size = '10'
        for k, v in options:
            setattr(self, str(k), v)
            print(k, ' = ', v)

    def run(self):
        axis = [0, 1, 1, 0]
        left, right, top, bottom = 0.07, 0.97, 0.93, 0.03
        lens1,chr_list1 = read_lens(self.lens1)# 染色体字典
        lens2,chr_list2 = read_lens(self.lens2)# 染色体字典
        gff1 = read_gff(self.gff1,chr_list1)# 基因字典
        gff2 = read_gff(self.gff2,chr_list2)# 基因字典

        # lens = dict( lens1, **lens2)#只有key是字符串的时候有用
        lens = lens1.copy()
        lens.update(lens2)
        gff = dict( gff1, **gff2)
        chr_list = list(set(chr_list1 + chr_list2))
        lens1sum = sum(lens1[key][self.position] for key in chr_list1)
        lens2sum = sum(lens2[key][self.position] for key in chr_list2)

        step1 = 1 / float(lens1sum)
        step2 = 1 / float(lens2sum)
        chr1_start = {}
        start = 0
        for chro in chr_list1:
            chr1_start[chro] = start
            start = start + lens1[chro][self.position]
        chr2_start = {}
        start = 0
        for chro in chr_list2:
            chr2_start[chro] = start
            start = start + lens2[chro][self.position]

        # print(chr1_start)

        colineartly = readcolineartly_dotplot(self.genepairs,int(self.block),int(self.block_gep),self.genepairsfile_type,gff,chr_list)
        x,y = [],[]
        for block in colineartly:
            for pair in block:
                x.append((chr1_start[gff[pair[0]]['chr']] + gff[pair[0]][self.position])*step1)
                y.append(-(chr2_start[gff[pair[1]]['chr']] + gff[pair[1]][self.position])*step2)
                if self.genepairsfile_type == 'MCScanX' and self.genome1_name == self.genome2_name:# MCScanX的结果只有a->b没有b->a
                    x.append((chr1_start[gff[pair[1]]['chr']] + gff[pair[1]][self.position])*step1)
                    y.append(-(chr2_start[gff[pair[0]]['chr']] + gff[pair[0]][self.position])*step2)

        if re.search('\d', self.figsize):
            self.figsize = [float(k) for k in self.figsize.split(',')]
        else:
            self.figsize = np.array(
                [1, float(lens1sum)/float(lens2sum)])*10

        plt.figure(figsize=self.figsize, dpi=600)
        plt.scatter(x,y,s = float(self.markersize))
        plt.axis ('off')
        plt.text((lens1sum/2)*step1, 0.045, self.genome1_name,ha='center',va='center',fontsize=int(self.genome_name_size))
        plt.text(-0.045, (-lens2sum/2)*step2, self.genome2_name,rotation=90,ha='center',va='center',fontsize=int(self.genome_name_size))
        for key in chr1_start.keys():
            x = chr1_start[key]
            plt.axvline(x=float(x)*step1, c="black", ls="-", lw=0.2)
            plt.text((x+(lens1[key][self.position]/2))*step1, 0.01, key,ha='center',va='center',fontsize=int(self.chr_name_size))
        plt.axvline(x=0*step1, c="black", ls="-", lw=2.5)
        plt.axvline(x=float(lens1sum)*step1, c="black", ls="-", lw=2.5)
        for key in chr2_start.keys():
            y = chr2_start[key]
            plt.axhline(y=-float(y)*step2, c="black", ls="-", lw=0.2)
            plt.text(-0.01, (-y-(lens2[key][self.position]/2))*step2, key,ha='center',va='center',rotation=90,fontsize=int(self.chr_name_size))#,rotation=30
        plt.axhline(y=-float(lens2sum)*step2, c="black", ls="-", lw=2.5)
        plt.axhline(y=-0*step2, c="black", ls="-", lw=2.5)
        plt.xlim(xmin = 0, xmax=1)
        plt.ylim(ymin = -1, ymax=0)

        plt.savefig(self.savefig, dpi=600)
        # plt.show()
        sys.exit(0)
